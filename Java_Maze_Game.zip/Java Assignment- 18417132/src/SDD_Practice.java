import java.util.Scanner;

public class SDD_Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean bool= false;
		String pass, confirm;
		int lengthCount=0;
		Scanner sc= new Scanner(System.in);
			
	do {
		System.out.println("Please enter a password");
		pass= sc.nextLine();
		System.out.println("Please re-enter the password");
		confirm= sc.nextLine();
	
	for(int i=0, j=0; i<pass.length() && j<confirm.length(); i++, j++) {
		if(pass.charAt(i)==pass.charAt(j)) {
			lengthCount++;
		}
	}
		if(lengthCount==pass.length() && lengthCount==confirm.length()) {
			System.out.println("The password is correct. Congratulations!");
		}
		else {
			System.out.println("The password is incorrect");
			System.out.println("Try again!");
			lengthCount=1;
		}
	}while(lengthCount!=pass.length() && lengthCount!=confirm.length());
	}

}